<template>
  <footer class="bg-light border-top mt-5">
    <div class="container py-4 d-flex flex-wrap gap-3 small">
      <span class="text-muted">© 2025 NFP (demo)</span>
      <a class="link-secondary" href="#">About</a>
      <a class="link-secondary" href="#">Privacy</a>
      <a class="link-secondary" href="#">Terms</a>
      <a class="link-secondary" href="#">Accessibility</a>
      <RouterLink class="link-secondary" to="/contact">Contact</RouterLink>
    </div>
  </footer>
</template>
