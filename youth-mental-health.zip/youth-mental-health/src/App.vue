<script setup>
import AppHeader from './components/AppHeader.vue'
import FooterBar from './components/FooterBar.vue'
</script>

<template>
  <AppHeader />
  <RouterView />
  <FooterBar />
</template>
